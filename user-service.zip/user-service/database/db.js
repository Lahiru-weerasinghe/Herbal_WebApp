module.exports = {
  db: "mongodb+srv://pinsara:pinsara@ayurvedicapp.fqdwbdz.mongodb.net/?retryWrites=true&w=majority",
};
